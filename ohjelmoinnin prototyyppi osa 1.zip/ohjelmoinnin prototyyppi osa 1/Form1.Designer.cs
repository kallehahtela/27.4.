﻿
namespace ohjelmoinnin_prototyyppi_osa_1
{
    partial class SisaankirjautumisForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.KirjautumisPanel = new System.Windows.Forms.Panel();
            this.VapaasanaPanel = new System.Windows.Forms.Panel();
            this.RekisteröintiPanel = new System.Windows.Forms.Panel();
            this.PoistaBT = new System.Windows.Forms.Button();
            this.TyhjennaBT = new System.Windows.Forms.Button();
            this.TallennaBT = new System.Windows.Forms.Button();
            this.TietotauluDG = new System.Windows.Forms.DataGridView();
            this.PaivitaBT = new System.Windows.Forms.Button();
            this.LuotunnusLB = new System.Windows.Forms.Label();
            this.IkäTB = new System.Windows.Forms.TextBox();
            this.IkäLB = new System.Windows.Forms.Label();
            this.SähköpostiTB = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.SukunimiTB = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.EtunimiTB = new System.Windows.Forms.TextBox();
            this.EtunimiLB = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.OtsikkoLB = new System.Windows.Forms.Label();
            this.TervetuloaPanel = new System.Windows.Forms.Panel();
            this.OhjelmtuotantoChekBox = new System.Windows.Forms.CheckBox();
            this.KehitysympäristöChekBox = new System.Windows.Forms.CheckBox();
            this.OhjelmprotoChekBox = new System.Windows.Forms.CheckBox();
            this.TenttiaikaCB = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.KieliLB = new System.Windows.Forms.Label();
            this.KieliCB = new System.Windows.Forms.ComboBox();
            this.SeuraavaBT = new System.Windows.Forms.Button();
            this.KurssitLB = new System.Windows.Forms.Label();
            this.OhjeLB = new System.Windows.Forms.Label();
            this.EmailTB = new System.Windows.Forms.TextBox();
            this.EmailLB = new System.Windows.Forms.Label();
            this.IkaTB = new System.Windows.Forms.TextBox();
            this.IkaLB = new System.Windows.Forms.Label();
            this.TervetuloaLB = new System.Windows.Forms.Label();
            this.KirjauduLB = new System.Windows.Forms.Label();
            this.KirjauduBT = new System.Windows.Forms.Button();
            this.SalasanaTB = new System.Windows.Forms.TextBox();
            this.SalasanaLB = new System.Windows.Forms.Label();
            this.KayttajaTB = new System.Windows.Forms.TextBox();
            this.KayttajaLB = new System.Windows.Forms.Label();
            this.KirjautumisPanel.SuspendLayout();
            this.VapaasanaPanel.SuspendLayout();
            this.RekisteröintiPanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.TietotauluDG)).BeginInit();
            this.TervetuloaPanel.SuspendLayout();
            this.SuspendLayout();
            // 
            // KirjautumisPanel
            // 
            this.KirjautumisPanel.Controls.Add(this.KirjauduLB);
            this.KirjautumisPanel.Controls.Add(this.KirjauduBT);
            this.KirjautumisPanel.Controls.Add(this.SalasanaTB);
            this.KirjautumisPanel.Controls.Add(this.SalasanaLB);
            this.KirjautumisPanel.Controls.Add(this.KayttajaTB);
            this.KirjautumisPanel.Controls.Add(this.KayttajaLB);
            this.KirjautumisPanel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.KirjautumisPanel.Location = new System.Drawing.Point(0, 0);
            this.KirjautumisPanel.Name = "KirjautumisPanel";
            this.KirjautumisPanel.Size = new System.Drawing.Size(939, 706);
            this.KirjautumisPanel.TabIndex = 0;
            // 
            // VapaasanaPanel
            // 
            this.VapaasanaPanel.Controls.Add(this.textBox1);
            this.VapaasanaPanel.Controls.Add(this.OtsikkoLB);
            this.VapaasanaPanel.Location = new System.Drawing.Point(0, 0);
            this.VapaasanaPanel.Name = "VapaasanaPanel";
            this.VapaasanaPanel.Size = new System.Drawing.Size(928, 590);
            this.VapaasanaPanel.TabIndex = 31;
            this.VapaasanaPanel.Visible = false;
            // 
            // RekisteröintiPanel
            // 
            this.RekisteröintiPanel.Controls.Add(this.PoistaBT);
            this.RekisteröintiPanel.Controls.Add(this.TyhjennaBT);
            this.RekisteröintiPanel.Controls.Add(this.TallennaBT);
            this.RekisteröintiPanel.Controls.Add(this.TietotauluDG);
            this.RekisteröintiPanel.Controls.Add(this.PaivitaBT);
            this.RekisteröintiPanel.Controls.Add(this.LuotunnusLB);
            this.RekisteröintiPanel.Controls.Add(this.IkäTB);
            this.RekisteröintiPanel.Controls.Add(this.IkäLB);
            this.RekisteröintiPanel.Controls.Add(this.SähköpostiTB);
            this.RekisteröintiPanel.Controls.Add(this.label3);
            this.RekisteröintiPanel.Controls.Add(this.SukunimiTB);
            this.RekisteröintiPanel.Controls.Add(this.label2);
            this.RekisteröintiPanel.Controls.Add(this.EtunimiTB);
            this.RekisteröintiPanel.Controls.Add(this.EtunimiLB);
            this.RekisteröintiPanel.Location = new System.Drawing.Point(30, 540);
            this.RekisteröintiPanel.Name = "RekisteröintiPanel";
            this.RekisteröintiPanel.Size = new System.Drawing.Size(928, 590);
            this.RekisteröintiPanel.TabIndex = 14;
            this.RekisteröintiPanel.Visible = false;
            this.RekisteröintiPanel.Paint += new System.Windows.Forms.PaintEventHandler(this.RekisteröintiPanel_Paint);
            // 
            // PoistaBT
            // 
            this.PoistaBT.Location = new System.Drawing.Point(264, 489);
            this.PoistaBT.Name = "PoistaBT";
            this.PoistaBT.Size = new System.Drawing.Size(203, 46);
            this.PoistaBT.TabIndex = 13;
            this.PoistaBT.Text = "Poista";
            this.PoistaBT.UseVisualStyleBackColor = true;
            // 
            // TyhjennaBT
            // 
            this.TyhjennaBT.Location = new System.Drawing.Point(33, 489);
            this.TyhjennaBT.Name = "TyhjennaBT";
            this.TyhjennaBT.Size = new System.Drawing.Size(203, 46);
            this.TyhjennaBT.TabIndex = 12;
            this.TyhjennaBT.Text = "Takaisin";
            this.TyhjennaBT.UseVisualStyleBackColor = true;
            // 
            // TallennaBT
            // 
            this.TallennaBT.Location = new System.Drawing.Point(264, 405);
            this.TallennaBT.Name = "TallennaBT";
            this.TallennaBT.Size = new System.Drawing.Size(203, 46);
            this.TallennaBT.TabIndex = 11;
            this.TallennaBT.Text = "Tallenna";
            this.TallennaBT.UseVisualStyleBackColor = true;
            // 
            // TietotauluDG
            // 
            this.TietotauluDG.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.TietotauluDG.Location = new System.Drawing.Point(496, 125);
            this.TietotauluDG.Name = "TietotauluDG";
            this.TietotauluDG.Size = new System.Drawing.Size(395, 437);
            this.TietotauluDG.TabIndex = 10;
            // 
            // PaivitaBT
            // 
            this.PaivitaBT.Location = new System.Drawing.Point(33, 405);
            this.PaivitaBT.Name = "PaivitaBT";
            this.PaivitaBT.Size = new System.Drawing.Size(203, 46);
            this.PaivitaBT.TabIndex = 9;
            this.PaivitaBT.Text = "Päivitä";
            this.PaivitaBT.UseVisualStyleBackColor = true;
            // 
            // LuotunnusLB
            // 
            this.LuotunnusLB.AutoSize = true;
            this.LuotunnusLB.Font = new System.Drawing.Font("Microsoft Sans Serif", 27.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LuotunnusLB.Location = new System.Drawing.Point(312, 26);
            this.LuotunnusLB.Name = "LuotunnusLB";
            this.LuotunnusLB.Size = new System.Drawing.Size(333, 42);
            this.LuotunnusLB.TabIndex = 8;
            this.LuotunnusLB.Text = "Luo käyttäjätunnus";
            // 
            // IkäTB
            // 
            this.IkäTB.Location = new System.Drawing.Point(169, 346);
            this.IkäTB.Name = "IkäTB";
            this.IkäTB.Size = new System.Drawing.Size(281, 31);
            this.IkäTB.TabIndex = 7;
            // 
            // IkäLB
            // 
            this.IkäLB.AutoSize = true;
            this.IkäLB.Location = new System.Drawing.Point(38, 346);
            this.IkäLB.Name = "IkäLB";
            this.IkäLB.Size = new System.Drawing.Size(46, 25);
            this.IkäLB.TabIndex = 6;
            this.IkäLB.Text = "Ikä:";
            // 
            // SähköpostiTB
            // 
            this.SähköpostiTB.Location = new System.Drawing.Point(169, 272);
            this.SähköpostiTB.Name = "SähköpostiTB";
            this.SähköpostiTB.Size = new System.Drawing.Size(281, 31);
            this.SähköpostiTB.TabIndex = 5;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(38, 272);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(125, 25);
            this.label3.TabIndex = 4;
            this.label3.Text = "Sähköposti:";
            // 
            // SukunimiTB
            // 
            this.SukunimiTB.Location = new System.Drawing.Point(169, 201);
            this.SukunimiTB.Name = "SukunimiTB";
            this.SukunimiTB.Size = new System.Drawing.Size(281, 31);
            this.SukunimiTB.TabIndex = 3;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(38, 201);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(106, 25);
            this.label2.TabIndex = 2;
            this.label2.Text = "Sukunimi:";
            // 
            // EtunimiTB
            // 
            this.EtunimiTB.Location = new System.Drawing.Point(169, 133);
            this.EtunimiTB.Name = "EtunimiTB";
            this.EtunimiTB.Size = new System.Drawing.Size(281, 31);
            this.EtunimiTB.TabIndex = 1;
            // 
            // EtunimiLB
            // 
            this.EtunimiLB.AutoSize = true;
            this.EtunimiLB.Location = new System.Drawing.Point(38, 133);
            this.EtunimiLB.Name = "EtunimiLB";
            this.EtunimiLB.Size = new System.Drawing.Size(89, 25);
            this.EtunimiLB.TabIndex = 0;
            this.EtunimiLB.Text = "Etunimi:";
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(79, 144);
            this.textBox1.Multiline = true;
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(766, 282);
            this.textBox1.TabIndex = 1;
            // 
            // OtsikkoLB
            // 
            this.OtsikkoLB.AutoSize = true;
            this.OtsikkoLB.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.OtsikkoLB.Location = new System.Drawing.Point(263, 47);
            this.OtsikkoLB.Name = "OtsikkoLB";
            this.OtsikkoLB.Size = new System.Drawing.Size(435, 33);
            this.OtsikkoLB.TabIndex = 0;
            this.OtsikkoLB.Text = "Voit antaa palautetta halutessasi";
            // 
            // TervetuloaPanel
            // 
            this.TervetuloaPanel.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.TervetuloaPanel.Controls.Add(this.OhjelmtuotantoChekBox);
            this.TervetuloaPanel.Controls.Add(this.KehitysympäristöChekBox);
            this.TervetuloaPanel.Controls.Add(this.OhjelmprotoChekBox);
            this.TervetuloaPanel.Controls.Add(this.TenttiaikaCB);
            this.TervetuloaPanel.Controls.Add(this.label1);
            this.TervetuloaPanel.Controls.Add(this.KieliLB);
            this.TervetuloaPanel.Controls.Add(this.KieliCB);
            this.TervetuloaPanel.Controls.Add(this.SeuraavaBT);
            this.TervetuloaPanel.Controls.Add(this.KurssitLB);
            this.TervetuloaPanel.Controls.Add(this.OhjeLB);
            this.TervetuloaPanel.Controls.Add(this.EmailTB);
            this.TervetuloaPanel.Controls.Add(this.EmailLB);
            this.TervetuloaPanel.Controls.Add(this.IkaTB);
            this.TervetuloaPanel.Controls.Add(this.IkaLB);
            this.TervetuloaPanel.Controls.Add(this.TervetuloaLB);
            this.TervetuloaPanel.Location = new System.Drawing.Point(0, 0);
            this.TervetuloaPanel.Name = "TervetuloaPanel";
            this.TervetuloaPanel.Size = new System.Drawing.Size(865, 791);
            this.TervetuloaPanel.TabIndex = 12;
            this.TervetuloaPanel.Visible = false;
            // 
            // OhjelmtuotantoChekBox
            // 
            this.OhjelmtuotantoChekBox.AccessibleRole = System.Windows.Forms.AccessibleRole.None;
            this.OhjelmtuotantoChekBox.AutoSize = true;
            this.OhjelmtuotantoChekBox.Location = new System.Drawing.Point(64, 377);
            this.OhjelmtuotantoChekBox.Name = "OhjelmtuotantoChekBox";
            this.OhjelmtuotantoChekBox.Size = new System.Drawing.Size(286, 29);
            this.OhjelmtuotantoChekBox.TabIndex = 30;
            this.OhjelmtuotantoChekBox.Text = "Ohjelmiston tuotantoversio";
            this.OhjelmtuotantoChekBox.UseVisualStyleBackColor = true;
            // 
            // KehitysympäristöChekBox
            // 
            this.KehitysympäristöChekBox.AccessibleRole = System.Windows.Forms.AccessibleRole.None;
            this.KehitysympäristöChekBox.AutoSize = true;
            this.KehitysympäristöChekBox.Location = new System.Drawing.Point(64, 432);
            this.KehitysympäristöChekBox.Name = "KehitysympäristöChekBox";
            this.KehitysympäristöChekBox.Size = new System.Drawing.Size(271, 29);
            this.KehitysympäristöChekBox.TabIndex = 29;
            this.KehitysympäristöChekBox.Text = "Kehitysympäristön käyttö";
            this.KehitysympäristöChekBox.UseVisualStyleBackColor = true;
            // 
            // OhjelmprotoChekBox
            // 
            this.OhjelmprotoChekBox.AccessibleRole = System.Windows.Forms.AccessibleRole.None;
            this.OhjelmprotoChekBox.AutoSize = true;
            this.OhjelmprotoChekBox.Location = new System.Drawing.Point(64, 322);
            this.OhjelmprotoChekBox.Name = "OhjelmprotoChekBox";
            this.OhjelmprotoChekBox.Size = new System.Drawing.Size(256, 29);
            this.OhjelmprotoChekBox.TabIndex = 28;
            this.OhjelmprotoChekBox.Text = "Ohjelmiston prototyyppi";
            this.OhjelmprotoChekBox.UseVisualStyleBackColor = true;
            // 
            // TenttiaikaCB
            // 
            this.TenttiaikaCB.FormattingEnabled = true;
            this.TenttiaikaCB.Items.AddRange(new object[] {
            "26.4.2022",
            "26.8.2022",
            "18.12.2022"});
            this.TenttiaikaCB.Location = new System.Drawing.Point(674, 141);
            this.TenttiaikaCB.Name = "TenttiaikaCB";
            this.TenttiaikaCB.Size = new System.Drawing.Size(214, 33);
            this.TenttiaikaCB.TabIndex = 24;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(370, 144);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(230, 25);
            this.label1.TabIndex = 22;
            this.label1.Text = "Valitse tenttiajankohta:";
            // 
            // KieliLB
            // 
            this.KieliLB.AutoSize = true;
            this.KieliLB.Location = new System.Drawing.Point(370, 204);
            this.KieliLB.Name = "KieliLB";
            this.KieliLB.Size = new System.Drawing.Size(288, 25);
            this.KieliLB.TabIndex = 20;
            this.KieliLB.Text = "Valitse oikea ohjelmointikieli:";
            // 
            // KieliCB
            // 
            this.KieliCB.FormattingEnabled = true;
            this.KieliCB.Items.AddRange(new object[] {
            "JavaScript",
            "C#"});
            this.KieliCB.Location = new System.Drawing.Point(674, 201);
            this.KieliCB.Name = "KieliCB";
            this.KieliCB.Size = new System.Drawing.Size(214, 33);
            this.KieliCB.TabIndex = 19;
            // 
            // SeuraavaBT
            // 
            this.SeuraavaBT.Location = new System.Drawing.Point(300, 507);
            this.SeuraavaBT.Name = "SeuraavaBT";
            this.SeuraavaBT.Size = new System.Drawing.Size(323, 60);
            this.SeuraavaBT.TabIndex = 18;
            this.SeuraavaBT.Text = "Seuraava";
            this.SeuraavaBT.UseVisualStyleBackColor = true;
            this.SeuraavaBT.Click += new System.EventHandler(this.SeuraavaBT_Click);
            // 
            // KurssitLB
            // 
            this.KurssitLB.AutoSize = true;
            this.KurssitLB.Location = new System.Drawing.Point(59, 268);
            this.KurssitLB.Name = "KurssitLB";
            this.KurssitLB.Size = new System.Drawing.Size(306, 25);
            this.KurssitLB.TabIndex = 16;
            this.KurssitLB.Text = "Valitse kurssi yksi tai useampi:";
            // 
            // OhjeLB
            // 
            this.OhjeLB.AutoSize = true;
            this.OhjeLB.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.OhjeLB.Location = new System.Drawing.Point(25, 80);
            this.OhjeLB.Name = "OhjeLB";
            this.OhjeLB.Size = new System.Drawing.Size(304, 25);
            this.OhjeLB.TabIndex = 15;
            this.OhjeLB.Text = "Älä jätä mitään kohtaa tyhjäksi";
            // 
            // EmailTB
            // 
            this.EmailTB.Location = new System.Drawing.Point(138, 201);
            this.EmailTB.Name = "EmailTB";
            this.EmailTB.Size = new System.Drawing.Size(210, 31);
            this.EmailTB.TabIndex = 4;
            // 
            // EmailLB
            // 
            this.EmailLB.AutoSize = true;
            this.EmailLB.Location = new System.Drawing.Point(7, 204);
            this.EmailLB.Name = "EmailLB";
            this.EmailLB.Size = new System.Drawing.Size(125, 25);
            this.EmailLB.TabIndex = 3;
            this.EmailLB.Text = "Sähköposti:";
            // 
            // IkaTB
            // 
            this.IkaTB.Location = new System.Drawing.Point(138, 144);
            this.IkaTB.Name = "IkaTB";
            this.IkaTB.Size = new System.Drawing.Size(174, 31);
            this.IkaTB.TabIndex = 2;
            // 
            // IkaLB
            // 
            this.IkaLB.AutoSize = true;
            this.IkaLB.Location = new System.Drawing.Point(7, 147);
            this.IkaLB.Name = "IkaLB";
            this.IkaLB.Size = new System.Drawing.Size(46, 25);
            this.IkaLB.TabIndex = 1;
            this.IkaLB.Text = "Ikä:";
            // 
            // TervetuloaLB
            // 
            this.TervetuloaLB.AutoSize = true;
            this.TervetuloaLB.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TervetuloaLB.Location = new System.Drawing.Point(368, 26);
            this.TervetuloaLB.Name = "TervetuloaLB";
            this.TervetuloaLB.Size = new System.Drawing.Size(167, 37);
            this.TervetuloaLB.TabIndex = 0;
            this.TervetuloaLB.Text = "Tervetuloa";
            // 
            // KirjauduLB
            // 
            this.KirjauduLB.AutoSize = true;
            this.KirjauduLB.Font = new System.Drawing.Font("Microsoft Sans Serif", 27.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.KirjauduLB.Location = new System.Drawing.Point(345, 26);
            this.KirjauduLB.Name = "KirjauduLB";
            this.KirjauduLB.Size = new System.Drawing.Size(245, 42);
            this.KirjauduLB.TabIndex = 11;
            this.KirjauduLB.Text = "Kirjautuminen";
            // 
            // KirjauduBT
            // 
            this.KirjauduBT.Location = new System.Drawing.Point(299, 334);
            this.KirjauduBT.Name = "KirjauduBT";
            this.KirjauduBT.Size = new System.Drawing.Size(323, 52);
            this.KirjauduBT.TabIndex = 10;
            this.KirjauduBT.Text = "Kirjaudu sisään";
            this.KirjauduBT.UseVisualStyleBackColor = true;
            this.KirjauduBT.Click += new System.EventHandler(this.KirjauduBT_Click);
            // 
            // SalasanaTB
            // 
            this.SalasanaTB.Location = new System.Drawing.Point(441, 243);
            this.SalasanaTB.Name = "SalasanaTB";
            this.SalasanaTB.Size = new System.Drawing.Size(181, 31);
            this.SalasanaTB.TabIndex = 9;
            // 
            // SalasanaLB
            // 
            this.SalasanaLB.AutoSize = true;
            this.SalasanaLB.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SalasanaLB.Location = new System.Drawing.Point(294, 243);
            this.SalasanaLB.Name = "SalasanaLB";
            this.SalasanaLB.Size = new System.Drawing.Size(108, 25);
            this.SalasanaLB.TabIndex = 8;
            this.SalasanaLB.Text = "Salasana:";
            // 
            // KayttajaTB
            // 
            this.KayttajaTB.Location = new System.Drawing.Point(442, 187);
            this.KayttajaTB.Name = "KayttajaTB";
            this.KayttajaTB.Size = new System.Drawing.Size(181, 31);
            this.KayttajaTB.TabIndex = 7;
            // 
            // KayttajaLB
            // 
            this.KayttajaLB.AutoSize = true;
            this.KayttajaLB.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.KayttajaLB.Location = new System.Drawing.Point(294, 187);
            this.KayttajaLB.Name = "KayttajaLB";
            this.KayttajaLB.Size = new System.Drawing.Size(96, 25);
            this.KayttajaLB.TabIndex = 6;
            this.KayttajaLB.Text = "Käyttäjä:";
            // 
            // SisaankirjautumisForm
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.ClientSize = new System.Drawing.Size(939, 706);
            this.Controls.Add(this.KirjautumisPanel);
            this.Controls.Add(this.TervetuloaPanel);
            this.Controls.Add(this.VapaasanaPanel);
            this.Controls.Add(this.RekisteröintiPanel);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(6);
            this.Name = "SisaankirjautumisForm";
            this.Text = "Ohjelmointi proto";
            this.Load += new System.EventHandler(this.SisaankirjautumisForm_Load);
            this.KirjautumisPanel.ResumeLayout(false);
            this.KirjautumisPanel.PerformLayout();
            this.VapaasanaPanel.ResumeLayout(false);
            this.VapaasanaPanel.PerformLayout();
            this.RekisteröintiPanel.ResumeLayout(false);
            this.RekisteröintiPanel.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.TietotauluDG)).EndInit();
            this.TervetuloaPanel.ResumeLayout(false);
            this.TervetuloaPanel.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel KirjautumisPanel;
        private System.Windows.Forms.Label KirjauduLB;
        private System.Windows.Forms.Button KirjauduBT;
        private System.Windows.Forms.TextBox SalasanaTB;
        private System.Windows.Forms.Label SalasanaLB;
        private System.Windows.Forms.TextBox KayttajaTB;
        private System.Windows.Forms.Label KayttajaLB;
        private System.Windows.Forms.Panel TervetuloaPanel;
        private System.Windows.Forms.Label TervetuloaLB;
        private System.Windows.Forms.TextBox EmailTB;
        private System.Windows.Forms.Label EmailLB;
        private System.Windows.Forms.TextBox IkaTB;
        private System.Windows.Forms.Label IkaLB;
        private System.Windows.Forms.Button SeuraavaBT;
        private System.Windows.Forms.Label KurssitLB;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label KieliLB;
        private System.Windows.Forms.ComboBox KieliCB;
        private System.Windows.Forms.Label OhjeLB;
        private System.Windows.Forms.ComboBox TenttiaikaCB;
        private System.Windows.Forms.CheckBox OhjelmtuotantoChekBox;
        private System.Windows.Forms.CheckBox KehitysympäristöChekBox;
        private System.Windows.Forms.CheckBox OhjelmprotoChekBox;
        private System.Windows.Forms.Panel VapaasanaPanel;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label OtsikkoLB;
        private System.Windows.Forms.Panel RekisteröintiPanel;
        private System.Windows.Forms.Label LuotunnusLB;
        private System.Windows.Forms.TextBox IkäTB;
        private System.Windows.Forms.Label IkäLB;
        private System.Windows.Forms.TextBox SähköpostiTB;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox SukunimiTB;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox EtunimiTB;
        private System.Windows.Forms.Label EtunimiLB;
        private System.Windows.Forms.Button PaivitaBT;
        private System.Windows.Forms.DataGridView TietotauluDG;
        private System.Windows.Forms.Button PoistaBT;
        private System.Windows.Forms.Button TyhjennaBT;
        private System.Windows.Forms.Button TallennaBT;
    }
}

