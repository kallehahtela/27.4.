﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ohjelmoinnin_prototyyppi_osa_1
{
    public partial class SisaankirjautumisForm : Form
    {

        public SisaankirjautumisForm()
        {
            InitializeComponent();
        }

        //Tarkastetaan onko käyttäjän antama salasana ja käyttäjä oikea
        //jos ei ole niin annettaan messageboksi näytölle
        //kaikki ok niin seuraava paneeli avautuu
        private void KirjauduBT_Click(object sender, EventArgs e)
        {
            if (KayttajaTB.Text == "sinun nimesi" & SalasanaTB.Text == "Ja@kk0Ku1t4")
            {   

                TervetuloaPanel.Visible = true;
            }
            else
            {
                MessageBox.Show("Salasana tai käyttäjä väärin");
            }

            
        }
        //määritetään minimi ikä lomakkeen täyttöön
        int Ika => 16;

        //tarkastetaan kaikki mitä lomakkeella on 
        //jos ei ole täytetty niin messageboksi tulee näytölle ja näyttää missä on vika
        //lopuksi avataan seuraava paneeli
        private void SeuraavaBT_Click(object sender, EventArgs e)
        {
            if (Ika > 16)
            {
                MessageBox.Show("Liian nuori");
            }
            else if (EmailTB.Text != "sinunnimesi@gmail.com")
            {
                MessageBox.Show("Tarkista sähköposti");
            }
            else if (TenttiaikaCB.SelectedItem == null)
            {
                MessageBox.Show("Tarkista oletko valinnut tenttiajan");
            }
            else if (KieliCB.SelectedItem == null)
            {
                MessageBox.Show("Tarkista oletko valinnut ohjelmointikielen");
            }
            else if (OhjelmprotoChekBox.Checked == false)
            {
                MessageBox.Show("Valitse ainakin yksi kurssi jota olet suorittamassa");
            }
            else if (OhjelmtuotantoChekBox.Checked == false)
            {
                MessageBox.Show("Valitse ainakin yksi kurssi jota olet suorittamassa");
            }
            else if (KehitysympäristöChekBox.Checked == false)
            {
                MessageBox.Show("Valitse ainakin yksi kurssi jota olet suorittamassa");
            }
            else
            {
                VapaasanaPanel.Visible = true;
            }
        }

        private void RekisteröidyBT_Click(object sender, EventArgs e)
        {
            RekisteröintiPanel.Visible = true;
        }

        private void RekisteröintiPanel_Paint(object sender, PaintEventArgs e)
        {

        }

        private void SisaankirjautumisForm_Load(object sender, EventArgs e)
        {

        }
    }
}

